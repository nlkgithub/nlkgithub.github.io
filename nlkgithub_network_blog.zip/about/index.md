---
layout: default
title: About
---

# About Me

I am **Nishendra Lakshitha**, a Network Engineer based in the UAE.

I write about practical network engineering, troubleshooting, lab work, and deployment experience.

## Technical Areas

- Cisco routing and switching
- Fortinet firewall and VPN
- MikroTik routing and failover
- Ubuntu Linux services
- Proxmox and virtualization
- WiFi troubleshooting
- IPTV and multicast
- Network monitoring
