---
layout: default
title: Certifications
---

# Certifications

- Fortinet NSE 7
- CCNA
- CCNP knowledge and lab practice
- Network security and firewall operations
