---
layout: default
title: Projects
---

# Projects

<div class="page-list">

<div class="card">
<h2>Self-hosted VPN with Headscale and Tailscale</h2>
<p>Built a self-hosted VPN control plane with custom domain, DERP, users, nodes, and route management.</p>
</div>

<div class="card">
<h2>Network Monitoring Dashboard</h2>
<p>Monitoring lab using LibreNMS, Checkmk, Grafana, SNMP, syslog, and Proxmox metrics.</p>
</div>

<div class="card">
<h2>IPTV and Multicast Troubleshooting</h2>
<p>Real-world IPTV notes covering IGMP snooping, multicast testing, VLAN design, and STB troubleshooting.</p>
</div>

</div>
