---
layout: post
title: "Cisco VLAN Troubleshooting Guide"
date: 2026-07-01
categories: cisco vlan troubleshooting
---

VLAN issues are common in enterprise networks. This is my basic troubleshooting flow.

## 1. Check interface status

```bash
show interfaces status
```

## 2. Verify VLAN exists

```bash
show vlan brief
```

## 3. Check trunk ports

```bash
show interfaces trunk
```

## 4. Check IP gateway

```bash
show ip interface brief
```

## 5. Test connectivity

```bash
ping <gateway-ip>
traceroute <destination-ip>
```

## Summary

Start from Layer 1, then Layer 2, then Layer 3. This method helps avoid missing simple issues.
