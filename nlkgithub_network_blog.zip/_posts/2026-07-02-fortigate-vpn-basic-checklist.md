---
layout: post
title: "FortiGate VPN Basic Troubleshooting Checklist"
date: 2026-07-02
categories: fortigate vpn firewall
---

This checklist helps when a FortiGate VPN is not coming up.

## Checks

1. Confirm WAN connectivity.
2. Verify peer public IP.
3. Check phase 1 proposal.
4. Check phase 2 selectors.
5. Verify firewall policies.
6. Check NAT exemption.
7. Review logs.

## Useful commands

```bash
get vpn ipsec tunnel summary
diagnose vpn tunnel list
diagnose debug application ike -1
diagnose debug enable
```

Always disable debug after testing:

```bash
diagnose debug disable
```
