---
layout: post
title: "Welcome to My Network Engineering Blog"
date: 2026-06-30
categories: networking career
---

Welcome to my Network Engineering Blog.

This website is where I publish practical notes, troubleshooting steps, and lab guides.

## Topics I will cover

- Cisco switching and routing
- FortiGate firewall and VPN
- MikroTik routing
- Ubuntu Linux services
- Proxmox networking
- WiFi troubleshooting
- IPTV and multicast
- Monitoring with LibreNMS and Checkmk
