---
layout: default
title: Resume
---

# Resume

## Nishendra Lakshitha

**Network Engineer | Fortinet | Cisco | Linux | Proxmox**

## Skills

Cisco, Fortinet, MikroTik, Huawei, Ubuntu, Proxmox, VMware, Docker, WiFi, IPTV, LibreNMS, Checkmk.

## Experience Summary

Network Engineer with practical experience in routing, switching, firewall, VPN, WiFi, Linux servers, monitoring, and troubleshooting.
